<?php

namespace Shatchi\ProductVariant\Plugin;

use Magento\ConfigurableProduct\Block\Product\View\Type\Configurable;
use Magento\Catalog\Model\ResourceModel\Product as ProductResource;
use Magento\Store\Model\StoreManagerInterface;

class ConfigurableJsonConfig
{
    /**
     * @var ProductResource
     */
    protected $productResource;

    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @param ProductResource $productResource
     * @param StoreManagerInterface $storeManager
     */
    public function __construct(
        ProductResource $productResource,
        StoreManagerInterface $storeManager
    ) {
        $this->productResource = $productResource;
        $this->storeManager = $storeManager;
    }

    /**
     * Inject product descriptions and custom Shatchi attributes into the configurable json config
     *
     * @param Configurable $subject
     * @param string $result
     * @return string
     */
    public function afterGetJsonConfig(
        Configurable $subject,
        $result
    ) {
        $config = json_decode($result, true);

        $product = $subject->getProduct();
        $childProducts = $product->getTypeInstance()->getUsedProducts($product);
        $storeId = $this->storeManager->getStore()->getId();
        $config['attribute_set_id'] = $product->getAttributeSetId();

        foreach ($childProducts as $child) {
            $childId = $child->getId();

            // Efficiently fetch custom attributes without loading the full product model
            // $attributes = ['description', 'short_description', 'shatchi_moq', 'shatchi_carton_price', 'shatchi_carton_qty'];
            $attributes = [
                            'description',
                            'short_description',
                            'shatchi_moq',
                            'shatchi_carton_price',
                            'shatchi_carton_qty',
                            'pack_per_piece',   // ✅ NEW
                            'leds_no'           // ✅ (ensure consistency)
                        ];

            // Get raw attribute values directly from the database to avoid N+1 loading performance issues
            $rawAttributes = $this->productResource->getAttributeRawValue($childId, $attributes, $storeId);

            if (is_array($rawAttributes)) {
                $description = isset($rawAttributes['description']) ? $rawAttributes['description'] : '';
                $shortDescription = isset($rawAttributes['short_description']) ? $rawAttributes['short_description'] : '';
                $shatchiMoq = isset($rawAttributes['shatchi_moq']) ? $rawAttributes['shatchi_moq'] : null;
                $shatchiCartonPrice = isset($rawAttributes['shatchi_carton_price']) ? $rawAttributes['shatchi_carton_price'] : null;
                $shatchiCartonQty = isset($rawAttributes['shatchi_carton_qty']) ? $rawAttributes['shatchi_carton_qty'] : null;
                $packPerPiece = isset($rawAttributes['pack_per_piece']) ? $rawAttributes['pack_per_piece'] : null;
                $ledsNo = isset($rawAttributes['leds_no']) ? $rawAttributes['leds_no'] : null;
            } else {
                // Fallback if the array format is not returned (e.g. asking for a single attribute)
                $description = '';
                $shortDescription = '';
                $shatchiMoq = null;
                $shatchiCartonPrice = null;
                $shatchiCartonQty = null;
            }

            $config['descriptions'][$childId] = $description ?: '';
            $config['shortDescriptions'][$childId] = $shortDescription ?: '';

            $config['shatchi_moq'][$childId] = $shatchiMoq > 0 ? (float)$shatchiMoq : 1;
            $config['shatchi_carton_price'][$childId] = $shatchiCartonPrice !== null ? (float)$shatchiCartonPrice : 0;
            $config['shatchi_carton_qty'][$childId] = $shatchiCartonQty > 0 ? (float)$shatchiCartonQty : 1;
            $config['pack_per_piece'][$childId] = $packPerPiece !== null ? $packPerPiece : '-';
            $config['leds_no'][$childId] = $ledsNo !== null ? $ledsNo : '-';
        }

        return json_encode($config);
    }
}
